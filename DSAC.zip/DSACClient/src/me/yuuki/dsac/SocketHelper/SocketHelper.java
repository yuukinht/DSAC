package me.yuuki.dsac.SocketHelper;

import java.io.DataOutputStream;
import java.net.Socket;
import me.yuuki.dsac.UI;

public class SocketHelper {
	public static void send(String data,String host,String port) {
		try {
			int p = Integer.valueOf(port);
			Socket s = new Socket(host,p);
			DataOutputStream dout = new DataOutputStream(s.getOutputStream());				
			dout.writeBytes(data);
			dout.flush();
			s.close();
			UI.textbox.setText("Đã hoàn thành!");
		}catch(Exception e) {
			UI.textbox.setText("Không thể kết nối!");
		}
	}
}
