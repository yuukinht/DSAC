package me.yuuki.dsac;

import java.awt.Dimension;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.Border;

import java.awt.Font;
import java.awt.Toolkit;

public class UI {

	private JFrame frame;
	public static JTextField textbox;
	public static void run() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UI window = new UI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public UI() {
		initialize();
	}

	private void initialize() {
		frame = new JFrame();
		frame.setAlwaysOnTop(true);
		frame.setBounds(100, 100, 450, 112);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		frame.setBounds((int) ((screenSize.getWidth() - frame.getWidth()) / 2),
                (int) ((screenSize.getHeight() - frame.getHeight()) / 2),
                frame.getWidth(), frame.getHeight());
		frame.setResizable(false);
		textbox = new JTextField() {
			private static final long serialVersionUID = 1L;
			@Override public void setBorder(Border border) {
		        // No!
		    }
		};
		textbox.setEditable(false);
		textbox.setFont(new Font("Arial", Font.BOLD, 24));
		textbox.setHorizontalAlignment(SwingConstants.CENTER);
		textbox.setText("Initing...");
		textbox.setBounds(10, 12, 414, 50);
		frame.getContentPane().add(textbox);
		textbox.setColumns(10);
	}
}
