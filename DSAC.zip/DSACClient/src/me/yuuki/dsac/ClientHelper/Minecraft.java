package me.yuuki.dsac.ClientHelper;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import me.yuuki.dsac.Main;

public class Minecraft {
	private String pid = null;
	private String username = null;
	private String version = null;
	private String gameDir = null;
	private String versionType = null;
	private String tweakClass = null;
	private String forgeType = null;
	private String clientIp = null;
	private String serverIp = null;
	private String serverPort = null;
	public String getServerIp() {
		return serverIp;
	}
	public void setServerIp(String serverIp) {
		this.serverIp = serverIp;
	}
	public String getServerPort() {
		return serverPort;
	}
	public void setServerPort(String serverPort) {
		this.serverPort = serverPort;
	}
	public String getClientJar() {
		return FileHelper.fileHash(getGameDir()+"\\versions\\"+getVersion()+"\\"+getVersion()+".jar");
	}
	@SuppressWarnings("resource")
	public String forgeVersion() {
		File file = new File(getGameDir()+"\\versions\\"+getVersion()+"\\"+getVersion()+".json");
		if(!file.exists()) {
			return null;
		}
		try {
			Scanner scan = new Scanner(file);
        	while(scan.hasNextLine()) {	         		
        		String line = scan.nextLine();
    			final Pattern pattern = Pattern.compile("\\\"jar\": \"(.*?)\"", Pattern.MULTILINE);
    			final Matcher matcher = pattern.matcher(line);
    			if(matcher.find()) {
        			return matcher.group(1);
    			}    			
        	}
        	scan.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return null;
	}
	public String[] getMods() {
		ArrayList<String> mods = new ArrayList<>();
		File folder = new File(getGameDir()+"\\mods");
		File[] list1 = folder.listFiles();
		if(list1!=null) {
			for (int i = 0; i < list1.length; i++) {
			  if (list1[i].isFile()) {
				  String hash = FileHelper.fileHash(getGameDir()+"\\mods\\"+list1[i].getName());
				  mods.add(hash);
			  }
			}
		}		
		File folder1 = new File(gameDir+"\\mods\\"+forgeVersion());
		if(folder.exists()) {
			File[] list2 = folder1.listFiles();
			if(list2!=null) {
				for (int i = 0; i < list2.length; i++) {
				  if (list2[i].isFile()) {
					  String hash = FileHelper.fileHash(getGameDir()+"\\mods\\"+forgeVersion()+"\\"+list2[i].getName());
					  mods.add(hash);
				  }
				}
			}			
		}	
		String[] modss = new String[mods.size()];
		int n=-1;
		for(String s: mods) {
			n++;
			modss[n]=s;
		}
		return modss;
	}
	private ArrayList<String> arr = new ArrayList<>();
	public Minecraft(String pid,String cmd) {
		this.pid = pid;
		this.arr = getArr(cmd);
		this.username = getField("--username");
		this.version = getField("--version");
		this.gameDir = getField("--gameDir");		
		this.versionType = getField("--versionType");
		this.tweakClass = getField("--tweakClass");
		if(this.tweakClass != null) {
			switch (this.tweakClass) {
			case "clientapi.load.ClientTweaker":
				setForgeType("Impact");
				break;
			case "baritone.launch.BaritoneTweaker":
				setForgeType("Impact");
				break;	
			case "net.labymod.vanillaforge.LabyModTweaker":
				setForgeType("Labymod");
				break;			
			case "net.badlion.client.tweaker.BadlionTweaker":
				setForgeType("Badlion");
				break;			
			case "optifine.OptiFineTweaker":
				setForgeType("Optifine");
				break;	
			default:
				setForgeType("Forge");
				break;
			}
		}
	}
	public String getInfo() {
		if(getForgeType()==null) {
			return getUsername()+";"+getForgeType()+";"+getClientJar();
		}else if(getForgeType().equals("Optifine")){
			for(String arrr : this.arr) {
				if(arrr.contains("libraries")) {
					String[] ars = arrr.split(";");
					for(String lib: ars) {
						if(lib.contains("libraries\\optifine\\OptiFine")) {
							return getUsername()+";"+getForgeType()+";"+FileHelper.fileHash(lib);
						}
					}
				}
			}			
			return null;
		}else if(getForgeType().equals("Forge")) {
			String[] list = getMods();
			String ar = null;
			for(String st : list) {
				if(ar==null) {
					ar=st;
				}else {
					ar+=","+st;
				}
			}
			return getUsername()+";"+getForgeType()+";"+ar;
		}else if(getForgeType().equals("Badlion")){
			return getUsername()+";"+getForgeType();
		}else if(getForgeType().equals("Labymod")){
			return getUsername()+";"+getForgeType();
		}
		return null;
	}
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public String getGameDir() {
		return gameDir;
	}
	public void setGameDir(String gameDir) {
		this.gameDir = gameDir;
	}
	public String getVersionType() {
		return versionType;
	}
	public void setVersionType(String versionType) {
		this.versionType = versionType;
	}
	public String getTweakClass() {
		return tweakClass;
	}
	public void setTweakClass(String tweakClass) {
		this.tweakClass = tweakClass;
	}
	public String getForgeType() {
		return forgeType;
	}
	public void setForgeType(String forgeType) {
		this.forgeType = forgeType;
	}
	public ArrayList<String> getArr(String cmd){
		ArrayList<String> arr = new ArrayList<>();
		Pattern regex = Pattern.compile("[^\\s\"']+|\"([^\"]*)\"|'([^']*)'");
		Matcher regexMatcher = regex.matcher(cmd);
		while (regexMatcher.find()) {
		    if (regexMatcher.group(1) != null) {
		    	arr.add(regexMatcher.group(1));
		    } else if (regexMatcher.group(2) != null) {
		    	arr.add(regexMatcher.group(2));
		    } else {
		    	arr.add(regexMatcher.group());
		    }
		}
		if(arr.size()>0) {
			return arr;
		}
		return null;
	}
	public String getField(String arg) {
		int id = this.arr.indexOf(arg);
		if(id>-1 && id<this.arr.size()-2) {
			return this.arr.get(id+1);
		}
		return null;
	}
	public void initIp() {
		try {
			Document doc = Jsoup.connect("http://ip-api.com/line/?fields=query").get();		
			if (doc.select("body").hasText()) {
				setClientIp(doc.select("body").text());
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public String getClientIp() {		
		return clientIp;
	}
	public void setClientIp(String clientIp) {
		this.clientIp = clientIp;
	}
	public boolean isConnect() {
		String line;
	    Process p;
		try {
			p = Runtime.getRuntime().exec("netstat -no");
			BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream()));
		    while ((line = input.readLine()) != null) {
		    	if(line.contains("EST") && line.endsWith(getPid())) {
		    		String regex = "([0-9]+.[0-9]+.[0-9]+.[0-9]+:[0-9]+)(.*?)([0-9]+.[0-9]+.[0-9]+.[0-9]+:[0-9]+)";
		    		final Pattern pattern = Pattern.compile(regex, Pattern.MULTILINE);
		    		final Matcher matcher = pattern.matcher(line);
		    		if(matcher.find()) {
		    			if(!matcher.group(1).contains("127.0.0.1")) {
		    				String ip = matcher.group(3);
		    				if(Main.list.contains(ip.split(":")[0])) {
		    					setServerIp(ip.split(":")[0]);
					    		setServerPort(ip.split(":")[1]);
					    		return true;
		    				}				    		
		    			}	    			
		    		}		    		
		    	}
		    }
		} catch (IOException e) {
			e.printStackTrace();
		}
		return false;
	}
}
