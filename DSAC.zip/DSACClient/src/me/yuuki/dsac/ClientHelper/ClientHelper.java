package me.yuuki.dsac.ClientHelper;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import me.yuuki.dsac.Main;

public class ClientHelper {
	public static boolean isOpenMinecraft() {
		try {
		    String line;
	    	final String regex = "--username(.*?)--version(.*?)--gameDir(.*?)--assetsDir(.*?)";
		    Process p = Runtime.getRuntime().exec("wmic path win32_process where (name='java.exe' or name='javaw.exe') get Commandline,Processid");
		    BufferedReader input =
		            new BufferedReader(new InputStreamReader(p.getInputStream()));
		    while ((line = input.readLine()) != null) {
		    	final Pattern pattern = Pattern.compile(regex, Pattern.MULTILINE);
	    		final Matcher matcher = pattern.matcher(line);
	    		if(matcher.find()) {
	    			String cmd = line.replaceAll("\\ +", " ").replaceAll("\\ $", "");
	    			String[] arg = cmd.split(" ");
	    			String pid = arg[arg.length-1];
	    			Main.mc = new Minecraft(pid, cmd);
	    			return true;
	    		}
		    }
		    input.close();
		} catch (Exception err) {
		    err.printStackTrace();
		}
		return false;
	}
	
}
