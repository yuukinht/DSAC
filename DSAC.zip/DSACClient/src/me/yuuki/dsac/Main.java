package me.yuuki.dsac;


import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

import me.yuuki.dsac.ClientHelper.ClientHelper;
import me.yuuki.dsac.ClientHelper.Minecraft;
import me.yuuki.dsac.SocketHelper.SocketHelper;

public class Main {
	public static String list = null;
	public static Minecraft mc = null;
	public static void main(String[] arg) {
		UI.run();
		list = getList();
		if(ClientHelper.isOpenMinecraft()) {
			mc.getMods();
			if(mc.isConnect()) {				
				if(!list.contains(mc.getServerIp())) {
					UI.textbox.setText("Server không hỗ trợ xác minh!");
				}else {					
					String data = mc.getInfo();
					if(data!=null) {						
						SocketHelper.send(data, mc.getServerIp(), "2468");					
					}else {
						UI.textbox.setText("Không thể xác minh!");
					}
				}			
			}else {
				UI.textbox.setText("Kiểm tra kết nối server!");
			}
		}else {
			UI.textbox.setText("Không tìm thấy Minecraft!");
		}
	}
	public static String getList() {
		try { 
            URL url=new URL("https://pastebin.com/raw/eZuTrsbp");
            URLConnection conn=url.openConnection();
            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String s;
            s=in.readLine();
            if(s!=null) {            	
            	return s;
            }
            in.close();
        } catch(Exception e) {
            e.printStackTrace();
        }
		return null;
	}
}